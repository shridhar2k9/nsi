/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

import {OverlayModule} from '@angular/cdk/overlay';
import {PortalModule} from '@angular/cdk/portal';
import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {MatCommonModule} from '@angular/material/core';
import {MAT_DIALOG_SCROLL_STRATEGY_PROVIDER, NielDialog} from './dialog';
import {NielDialogContainer} from './dialog-container';
import {
  NielDialogActions,
  NielDialogClose,
  NielDialogContent,
  NielDialogTitle,
} from './dialog-content-directives';


@NgModule({
  imports: [
    CommonModule,
    OverlayModule,
    PortalModule,
    MatCommonModule,
  ],
  exports: [
    NielDialogContainer,
    NielDialogClose,
    NielDialogTitle,
    NielDialogContent,
    NielDialogActions,
    MatCommonModule,
  ],
  declarations: [
    NielDialogContainer,
    NielDialogClose,
    NielDialogTitle,
    NielDialogActions,
    NielDialogContent,
  ],
  providers: [
    NielDialog,
    MAT_DIALOG_SCROLL_STRATEGY_PROVIDER,
  ],
  entryComponents: [NielDialogContainer],
})
export class MatDialogModule {}