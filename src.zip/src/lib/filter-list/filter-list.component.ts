import {Component,OnInit,Input,Output,EventEmitter} from '@angular/core';
import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
    selector:'niel-list-filter',
    styleUrls:['./filter-list.scss'],
    templateUrl:'./filter-list.html',
})
export class ListFilterComponent implements OnInit{
    highlight: any;
    @Input() data:any;
    @Output() filterData: EventEmitter<any> = new EventEmitter();
    ngOnInit(){
    }
    list_select(id):void{
        this.highlight=id;
        this.filterData.next(id)
    }
}

@NgModule({
    imports:[CommonModule],
    exports:[ListFilterComponent],
    declarations:[ListFilterComponent],
})
export class FilterListModule{

}