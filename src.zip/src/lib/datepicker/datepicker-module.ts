/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

import {A11yModule} from '@angular/cdk/a11y';
import {OverlayModule} from '@angular/cdk/overlay';
import {PortalModule} from '@angular/cdk/portal';
import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule} from '@angular/material/dialog';
import {NielCalendar, NielCalendarHeader} from './calendar';
import {NielCalendarBody} from './calendar-body';
import {NielDatepicker, NielDatepickerContent} from './datepicker';
import {NielDatepickerInput} from './datepicker-input';
import {NielDatepickerIntl} from './datepicker-intl';
import {NielDatepickerToggle, NielDatepickerToggleIcon} from './datepicker-toggle';
import {NielMonthView} from './month-view';
import {NielMultiYearView} from './multi-year-view';
import {NielYearView} from './year-view';
@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatDialogModule,
    OverlayModule,
    A11yModule,
    PortalModule
  ],
  exports: [
    NielCalendar,
    NielCalendarBody,
    NielDatepicker,
    NielDatepickerContent,
    NielDatepickerInput,
    NielDatepickerToggle,
    NielDatepickerToggleIcon,
    NielMonthView,
    NielYearView,
    NielMultiYearView,
    NielCalendarHeader,
  ],
  declarations: [
    NielCalendar,
    NielCalendarBody,
    NielDatepicker,
    NielDatepickerContent,
    NielDatepickerInput,
    NielDatepickerToggle,
    NielDatepickerToggleIcon,
    NielMonthView,
    NielYearView,
    NielMultiYearView,
    NielCalendarHeader,
  ],
  providers: [
    NielDatepickerIntl,
  ],
  entryComponents: [
    NielDatepickerContent,
    NielCalendarHeader,
  ]
})
export class NielDatepickerModule {}