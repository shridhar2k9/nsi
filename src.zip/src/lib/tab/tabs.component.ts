import { NgModule,OnInit,OnChanges,HostListener } from '@angular/core';
import {CommonModule} from '@angular/common';

import { Component,Input, ContentChildren, QueryList, AfterContentInit,Output,EventEmitter } from '@angular/core';
import { TabComponent } from './tab.component';

@Component({
  selector: 'niel-tab',
  styleUrls: ['./tabs.component.scss'],
  templateUrl: './tabs.component.html',
})
export class TabsComponent implements AfterContentInit {
  
  activeTabs: TabComponent;
  scrolly:number;
  @ContentChildren(TabComponent) tabs: QueryList<TabComponent>;
  @Output() tabChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() activeTab: EventEmitter<any> = new EventEmitter<any>();
  @Input() metadata:any;
  @Input()isSticky:boolean;
  @Output() onTabCloseClick: EventEmitter<any> = new EventEmitter();
  @HostListener('scroll', ['$event'])

  // contentChildren are set
  ngAfterContentInit() {
    // get all active tabs
    let activeTabs = this.tabs.filter((tab)=>tab.active);
    // if there is no active tab set, activate the first
    if(this.activeTabs){
      this.selectTab(this.activeTabs,true);
    }else{
      this.selectTab(this.tabs.first,true);
    }
  }
  ngOnChanges(){
    // console.log(this.tabs)
    // this.ngAfterContentInit()
  }
  
  selectTab(tab: TabComponent,onInit?:boolean){
    // deactivate all tabs

    // activate the tab the user has clicked on.
    if(tab){
      this.tabs.toArray().forEach(_tab => _tab.active = false);
      tab.active = true;
      this.tabChange.next(tab.title)
      // this.activeTab.next({metadata:this.metadata,tab:tab,onInit:onInit})
      this.activeTabs=tab
    }
    
  }
 
close(event: Event, tab) { 
    let index=this.findTabIndex(tab);
    let isactive=tab.active;
      let temp=this.metadata.filter(ele=>ele.title!=tab.title)
      // for(var i=0;i<=this.tabs.length;i++){
      //   this.tabs[i].active=true;
      //   break;
      // }
      this.onTabCloseClick.emit(temp)     
      let activeTabs = this.tabs.filter((tab)=>tab.active);
    // if there is no active tab set, activate the first
      this.selectTab(this.tabs.first,true);
      // console.log(this.tabs)    
  // event.stopPropagation();
}

findTabIndex(tab) {
  let index = -1;
  for(let i = 0; i < this.tabs['_results'].length; i++) {
      if(this.tabs['_results'][i] == tab) {
          index = i;
          break;
      }
  }
  return index;
}
prev() {
  var elmnt = document.getElementById("myDIV");
  elmnt.scrollLeft-=100;
}
next() {
  var elmnt = document.getElementById("myDIV");
  elmnt.scrollLeft+=100;
}
}


@NgModule({
    imports: [CommonModule],
    exports: [TabComponent,TabsComponent],
    declarations: [TabComponent,TabsComponent]
    })
    export class TabModule { }
