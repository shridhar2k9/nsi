export class Message {
    public message : string;
    public type : MessageType;

    constructor(message : string, type : MessageType) {
        this.message = message;
        this.type = type;
        
    }
}

export enum MessageType {
    Error = 1,
    Success = 2,
    Info = 3,
    Warning = 4,
    Primary = 5,
}