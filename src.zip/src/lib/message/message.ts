import { Component, OnInit, ViewChild, ElementRef, Input, AfterViewInit, OnDestroy, NgModule } from '@angular/core';
import { MessageService } from './message.service';
import { MessageType, Message } from './message.model';
import { Subscription } from 'rxjs';
import { DomHandler } from '../../helper/dom/domhandler';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'niel-message',
    styleUrls:['./css/icons.css'],
    template: `<div #container *ngFor="let m of value">
    <div class="alert alert-dismissible w-100  mt-3" [ngClass]="m.type == 1 ? 'red_toast' :
                                                        m.type == 2 ? 'green_toast' :
                                                        m.type == 3 ? 'alert-info' : 
                                                        m.type == 4 ? 'yellow_toast' : 'alert-primary'">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        {{m.message}}
    </div>
   
</div>
`
})
export class MessageComponent implements OnInit, AfterViewInit, OnDestroy {

    @ViewChild('container') containerViewChild: ElementRef;
    @Input() life: number = 300;
    subscription: Subscription;
    _value: Message[];
    @Input() immutable: boolean = true;
    timeout: any;

    constructor(public messageService: MessageService, public domHandler: DomHandler) {
        if (messageService) {
            this.subscription = messageService.messageObserver.subscribe(messages => {
                console.log(messages)
                if (messages) {
                    if (messages instanceof Array)
                        this.value = this.value ? [...this.value, ...messages] : [...messages];
                    else
                        this.value = this.value ? [...this.value, ...[messages]] : [messages];
                }
                else {
                    this.value = null;
                }
            });
        }
    }

    @Input() get value(): Message[] {
        return this._value;
    }

    ngAfterViewInit(): void {
        this.initTimeout();
    }

    set value(val: Message[]) {
        this._value = val;
        if (this.containerViewChild && this.containerViewChild.nativeElement && this.immutable) {
            this.handleValueChange();
        }
    }

    ngOnInit() {
    }

    handleValueChange() {
        this.domHandler.fadeIn(this.containerViewChild.nativeElement, 2000);
        this.initTimeout();
    }

    initTimeout() {
        if (this.timeout) {
            clearTimeout(this.timeout);
        }
        this.timeout = setTimeout(() => {
            this.removeAll();
        }, this.life);
    }

    removeAll() {
        if (this.value && this.value.length) {
            this.domHandler.fadeOut(this.containerViewChild.nativeElement, 2000);
            setTimeout(() => {
                if (this.immutable) {
                    this.value = [];
                }
                else {
                    this.value.splice(0, this.value.length);
                }
            }, 2000);
        }
    }

    ngOnDestroy() {
            clearTimeout(this.timeout);
        
        if(this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}

@NgModule({
    imports: [CommonModule],
    exports: [MessageComponent],
    declarations: [MessageComponent],
    providers : [DomHandler]
})
export class MessageModule { }