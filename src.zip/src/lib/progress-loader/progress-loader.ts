import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgressLoaderComponent } from './progress-loader.component';
import { LoadingConfigService } from './progress-loader.service';
import { ILoadingConfig, ANIMATION_TYPES } from './progress-loader.config';


@NgModule({
    imports: [CommonModule],
    exports: [ProgressLoaderComponent],
    declarations: [ProgressLoaderComponent],
    providers: [LoadingConfigService]
})
export class ProgressLoaderModule {
    static forRoot(loadingConfig: ILoadingConfig): ModuleWithProviders {
        return {
            ngModule: ProgressLoaderModule,
            providers: [{ provide: 'loadingConfig', useValue: loadingConfig }]
        };
    }
}
