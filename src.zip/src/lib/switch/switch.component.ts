import {Component,ViewChild,Input,Output,EventEmitter,ElementRef,forwardRef,HostListener,Renderer,OnChanges,HostBinding} from '@angular/core';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {NG_VALUE_ACCESSOR,ControlValueAccessor} from '@angular/forms';
export const INPUTSWITCH_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => NielSwitchComponent),
    multi: true
  };
@Component({
    selector:'NielSwitch',
    templateUrl:'./switch.component.html',
    styleUrls:['./switch.component.css'],
    providers:[INPUTSWITCH_VALUE_ACCESSOR]
})
export class NielSwitchComponent implements ControlValueAccessor{
    @Input()disabled : boolean;
    @Output()status:EventEmitter<any>=new EventEmitter();
    onModelChange: Function = () => {};
    onModelTouched: Function = () => {};
    label:string='theme';
    // dis:boolean=false;
    flag:boolean;
    slider: any;
    indicator: any;
    checked: boolean;
    theme = ''; // No initial theme set
constructor(private el:ElementRef){
}
/**
 * 
 * @param event capture boolean value on  every click event
 * @param input Referrence value of input element
 */
toggle(event,input){
    if(this.checked){
        if(event.srcElement.checked){
            this.checked = false;
            this.disable();            
           }
    }
    else{
        this.checked = true;
        this.enable();
    }
    this.onModelChange(this.checked);
    this.status.emit({
        originalEvent: event,
        checked: !event.srcElement.checked
    });
    input.focus();
}
/**
 * 
 * @param checked using valueAccessor's api's writevalue will get a value from model to view and vise 
 * versa 
 */
writeValue(checked: any) : void {
    this.slider=this.queryElement(this.el.nativeElement.children[0],"span.slider");
    this.indicator=this.queryElement(this.el.nativeElement.children[0],"span.round");
    this.checked=checked;
  if(this.disabled){
    if(checked){
    this.disable();
    this.checked=false;
   }
}
else{
    this.enable();
    this.checked=true;
}
}
registerOnChange(fn: Function): void {
    this.onModelChange = fn;
}

registerOnTouched(fn: Function): void {
    this.onModelTouched = fn;
}

setDisabledState(val: boolean): void {
    this.disabled = val;
}
enable(){
    this.slider.style.background = '#D4EEFD';
    this.indicator.style.right = 0 + 'px';
    this.indicator.style.left = 'auto';
    this.webkitTrans();
}
disable(){
    this.slider.style.background = '#ccc';
    this.indicator.style.left = 0 + 'px';
    this.indicator.style.right = 'auto';
    this.webkitTrans();
}
webkitTrans(){
    this.slider.style.WebkitTransition= .4 + 's';
    this.slider.style.transition= .4 + 's';
    this.indicator.style.WebkitTransition= .4 + 's';
    this.indicator.style.transition= .4 + 's';
}
queryElement(element: any, selector: string): any {
    return element.querySelector(selector);
}
setTheme(theme){
    this.theme = theme;
  }
}

@NgModule({
    declarations:[NielSwitchComponent],
    imports:[CommonModule],
    exports:[NielSwitchComponent],
})

export class NielSwitchModule{}