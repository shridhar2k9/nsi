import { NgModule } from '@angular/core';
import { ArrayToLabelValuePipe, CollectionToLabelValuePipe } from './pipes/common.pipe';


@NgModule({
  declarations: [
    ArrayToLabelValuePipe,
    CollectionToLabelValuePipe
  ],
  exports :[
    ArrayToLabelValuePipe,
    CollectionToLabelValuePipe
  ],
  imports: [
  ],
  providers: [],
})
export class HelperModule { }
