import { RequestOptions, URLSearchParams } from '@angular/http';

export class ExtensionService {

    protected getRequestOptions(options: any): RequestOptions {
        let params = new URLSearchParams();
        options.forEach(obj => {
            Object.keys(obj).forEach((key) => {
                params.paramsMap.set(key, [obj[key]]);
            });
        });
        let requestOptions: RequestOptions = new RequestOptions();
        requestOptions.params = params;

        return requestOptions;
    }
}