import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'arraytolabelvalue' })
export class ArrayToLabelValuePipe implements PipeTransform {
  
  transform(value, args: string[]): any {
    let values = [];
    for (let key of value) {
      values.push({ label: key, value: key });
    }
    return values;
  }
}

@Pipe({ name: 'collectiontolabelvalue' })
export class CollectionToLabelValuePipe implements PipeTransform {
  
  transform(value : any[], arg1 : any): any {
    let values = [];
    for (let key of value) {
      values.push({ label: key[arg1], value: key });
    }
    return values;
  }
}