Coercion
Utility functions for coercing @Inputs into specific types.