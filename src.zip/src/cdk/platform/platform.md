Platform
A service for determing the current platform.