Viewport
A utility for getting the bounds of the browser viewport.