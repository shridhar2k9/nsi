import { Injectable } from '@angular/core';
import { Http, ConnectionBackend, RequestOptions, RequestOptionsArgs, Response, Headers, Request, XHRBackend } from '@angular/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { tap,catchError,finalize} from 'rxjs/operators';

import { SharedService } from './shared.service';
import { MessageService, MessageType } from '../../../lib/lib.module';
@Injectable()
export class HttpInterceptor extends Http {

    constructor(backend: ConnectionBackend, defaultOptions: RequestOptions, private sharedService: SharedService, private messageService: MessageService) {
        super(backend, defaultOptions);
    }

    get(url: string, options?: RequestOptionsArgs): Observable<any> {
        this.beforeRequest();
        return super.get(this.getFullUrl(url), this.getOptions(options)).pipe(tap(response => this.checkStatus(response)),catchError(err => this.logError(err)),finalize(() => { this.afterRequest() }));
    }
    post(url: string, body: any, options?: RequestOptionsArgs): Observable<any> {
        this.beforeRequest();
        return super.post(this.getFullUrl(url), body, this.getOptions(options)).pipe(tap(response => this.checkStatus(response)),catchError(err => this.logError(err)),finalize(() => { this.afterRequest() }));
    }
    private getFullUrl(url: string): string {
        return environment.apiEndpoint + url;
    }

    private beforeRequest(): void {
        this.sharedService.setStatus(true);
    }

    private afterRequest(): void {
        this.sharedService.setStatus(false);
    }

    private getOptions(options?: RequestOptionsArgs): RequestOptionsArgs {
        let requestOptions: RequestOptionsArgs = options || new RequestOptions({ headers: new Headers() });
        return requestOptions;
    }

    private checkStatus(response: any): void {
        if (response.status != 200) {
            this.messageService.addMessage(response.message, MessageType.Error);
        }
    }

    private logError(ex: any): any {
        // Bad Request
        if (ex.status == 400) {
            this.logBadRequest(ex);
        }
        else {
            let exception = JSON.parse(ex._body);
            let message: string = ex.status + ": " + exception.error + "\t path : " + exception.path;
            this.messageService.addMessage(message, MessageType.Error);
        }

        return Observable.throw(ex);
    }

    private logBadRequest(ex : any) {
        console.log(ex._body);
        let message: string = ex.status + ": " + ex._body;
        this.messageService.addMessage(message, MessageType.Error);
    }
}


export function HttpFactory(backend: XHRBackend, defaultOptions: RequestOptions, sharedService: SharedService, messageService: MessageService) {
    return new HttpInterceptor(backend, defaultOptions, sharedService, messageService);
}

