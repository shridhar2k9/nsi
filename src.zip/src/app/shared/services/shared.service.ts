import { Injectable } from '@angular/core';

@Injectable()
export class SharedService {
    private _isBusy = false;

    public get isBusy(): boolean {
        return this._isBusy;
    }

    constructor() { }

    setStatus(value: boolean) {
        this._isBusy = value
    }
}
