import { HttpInterceptor } from './services/interceptor.service';
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HelperModule } from "../../helper/helper.module";
import { ProgressLoaderModule } from '../../lib/lib.module';
import { SharedService } from "./services/shared.service";
import {DialogOverviewExampleDialog} from './component/dialog-overview.component'
import { DropdownModule} from '../../lib/lib.module';

@NgModule({
    imports: [CommonModule,DropdownModule],
    exports: [DialogOverviewExampleDialog],
    declarations: [DialogOverviewExampleDialog],
    providers: [SharedService, HttpInterceptor]
})

export class SharedModule { }