import{Component,Inject} from '@angular/core';
import {NielDialog,NielDialogRef, MAT_DIALOG_DATA} from '../../../lib/lib.module';
import { Source } from '../../survey/survey-panel/survey';

@Component({
    selector: 'dialog-overview-example-dialog',
    templateUrl:'dialog-overview.component.html',
    styleUrls: ['./dialog-overview.component.scss'],
  })
  export class DialogOverviewExampleDialog  {
    addsourcedrop: { label: string; value: string; }[];
  
    constructor(
      public dialogRef: NielDialogRef<DialogOverviewExampleDialog>,
      @Inject(MAT_DIALOG_DATA) public data: any) {
   this.addsourcedrop=Source;
      }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
   
  }