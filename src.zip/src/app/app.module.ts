import { ProgressLoaderModule } from './../lib/progress-loader/progress-loader';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HelperModule } from '../helper/helper.module';
import { SurveyModule } from './survey/survey.module';
import { MessageService, MessageModule,DropdownModule } from '../lib/lib.module';
import { MatNativeDateModule } from '@angular/material';
import { LandingComponent } from './landing/landing.component';
import {CommonModule} from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
  ],
  imports: [
    MatNativeDateModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,

    // Angular module for the project
    AppRoutingModule,
    HelperModule,
    SurveyModule,
    MessageModule,
    CommonModule,
    DropdownModule    
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA
  ],
  providers: [{provide: LocationStrategy, useClass:HashLocationStrategy}, MessageService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
