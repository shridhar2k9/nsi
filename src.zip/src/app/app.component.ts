import { Component,OnInit } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  selected_theme:any;
  constructor(private overlay: OverlayContainer) { }
  ngOnInit(){
    document.body.classList.add("mat-light-theme", "mat-app-background");
    this.overlay.getContainerElement().classList.add("mat-light-theme");
  }
theme_arr=[
    {label:"Light",value:"mat-light-theme"},
    {label:"Dark",value:"mat-dark-theme"}
]
  toggleTheme(event): void {
    this.selected_theme=event.value
    let prev_theme = this.overlay.getContainerElement().classList[1];
    this.overlay.getContainerElement().classList.remove(prev_theme);
    document.body.classList.remove(prev_theme);
    this.overlay.getContainerElement().classList.add(this.selected_theme);
    document.body.classList.add(this.selected_theme);
    // if (this.overlay.getContainerElement().classList.contains("mat-dark-theme")) {
    //   this.overlay.getContainerElement().classList.remove("mat-dark-theme");
    //   this.overlay.getContainerElement().classList.add("mat-light-theme");
    // } else if (this.overlay.getContainerElement().classList.contains("mat-light-theme")) {
    //   this.overlay.getContainerElement().classList.remove("mat-light-theme");
    //   this.overlay.getContainerElement().classList.add("mat-dark-theme");
    // } else {
    //   this.overlay.getContainerElement().classList.add("mat-light-theme");
    // }
    // if (document.body.classList.contains("mat-dark-theme")) {
    //   document.body.classList.remove("mat-dark-theme");
    //   document.body.classList.add("mat-light-theme");
    // } else if (document.body.classList.contains("mat-light-theme")) {
    //   document.body.classList.remove("mat-light-theme");
    //   document.body.classList.add("mat-dark-theme");
    // } else {
    //   document.body.classList.add("mat-light-theme");
    // }
  }
}
