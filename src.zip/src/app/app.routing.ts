import { ModuleWithProviders,NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingComponent } from './landing/landing.component';
const appRoutes: Routes = [
	{
		path: '',
		component: LandingComponent,
		pathMatch: 'full'
	},{
		path: 'operation-portal',
		loadChildren: './survey/survey.module#SurveyModule',
	},{
		path: 'client-instruction',
		loadChildren: './client-instruction/client-instruction.module#ClientinstructioModule',
	}
];
@NgModule({
	imports: [RouterModule.forRoot(appRoutes)],
	exports: [RouterModule]
  })
  export class AppRoutingModule {}