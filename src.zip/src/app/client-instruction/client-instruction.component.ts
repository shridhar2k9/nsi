import {Component,OnInit} from '@angular/core';
import { surveyinfo,surveydimension,sourcedimension,Source,configuration,cars } from './client-instruction.model';
import {NielDialog,NielDialogRef} from '../../lib/lib.module';
import { DialogOverviewExampleDialog } from '../shared/component/dialog-overview.component';
@Component({
    selector:'client-instruction-portal',
    templateUrl:'client-instruction.component.html',
    styleUrls:[`client-instruction.component.scss`]
})
export class Clientinstruction implements OnInit {
  animal: any;
  switch: boolean;
    sourceCars: any;
    targetCars: any[];
    source_dimention: { title: string; }[];
  survey_dimension: { title: string; }[];
  survey_data: { id: number; name: string; }[];
  config=configuration;
  fruits = [
    { name: 'PeriodId' },
    { name: 'FrequencyId' },
    { name: 'YearNUM' },
    { name: 'SequenNUM' },
    { name: 'SequenId' },
    { name: 'InIDTE' },
  ];
    constructor(public dialog: NielDialog){}
ngOnInit(){
    this.survey_data=surveyinfo;
    this.survey_dimension=surveydimension;    
    this.source_dimention=sourcedimension;
    
    this.sourceCars = cars
    this.targetCars = [];
    this.switch=false;
}
// getSurveys(): void {
//     this.clientservice.getSurveyByClient(this.selectedClients).subscribe(data => {
//       this.surveys = data;
//     });
//   }
  remove(fruit: any): void {
      alert('hi')
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }
  // 
  toggle(event){
    // console.log(event)
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '400px',
      data: { name: 'asdadasda', animal: "csdfsdsdsds" }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
}
onclose(event):void{
  this.survey_dimension=event
}
}