export const surveyinfo=[{id:1,name:"0000-01-01"},{id:2,name:"0000-01-02"},{id:3,name:"0000-01-03"},{id:4,name:"0000-01-04"},{id:5,name:"0000-01-05"},{id:6,name:"0000-01-06"},{id:1,name:"0000-01-01"},{id:2,name:"0000-01-02"},{id:3,name:"0000-01-03"},{id:4,name:"0000-01-04"},{id:5,name:"0000-01-05"},{id:6,name:"0000-01-06"}]
export const surveydimension=[{title:"MARKET"},{title:"PRODUCT"},{title:"EXHIBITION"},{title:"LOCATION"},{title:"PERIOD"}];
export const sourcedimension=[{title:"Store"},{title:"Exhibitor"},{title:"Period"},{title:"Product"},{title:"Location"},{title:"Fact"}];
export const Source=[
    {label:"Name",value:"Name"},
    {label:"Feed",value:"Feed"},
    {label:"Format",value:"Format"},
    {label:"Type",value:"Type"}
]
export const configuration=["References","Static & Dynamic Headers","Reporting Characteristics","Hierarchy","Filter","References","Static & Dynamic Headers","Reporting Characteristics"];
export const cars=[
    {label:'Self Reference(Master)'},
    {label:'Self Reference'}
]