import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import { Clientinstruction} from './client-instruction.component';
import{ NielExpansionModule, MultiSelectModule, ProgressLoaderModule,
    TabModule,MessageService,MatChipsModule,DropdownModule,FilterListModule,PickListModule,NielSwitchModule,MatCardModule} from '../../lib/lib.module';
import { DialogOverviewExampleDialog } from "../shared/component/dialog-overview.component";
import { SharedModule } from '../shared/shared.module';

const clientRoutes: Routes = [
	{
		path: '',
		component: Clientinstruction,
	}
];
@NgModule({
    declarations:[Clientinstruction],
    imports:[
        RouterModule.forChild(clientRoutes),
        FormsModule,
        CommonModule,
        SharedModule,
        NielExpansionModule,
        MultiSelectModule, 
        ProgressLoaderModule,
        TabModule,
        MatChipsModule,
        DropdownModule,
        FilterListModule,
        PickListModule,
        NielSwitchModule,
        MatCardModule,
    ],
    exports:[],
    entryComponents:[DialogOverviewExampleDialog],
    bootstrap:[Clientinstruction],
    providers:[MessageService]
})
export class ClientinstructioModule{}