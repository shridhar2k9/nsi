import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SurveyPanelComponent } from "./survey-panel/survey-panel.component";
import { HelperModule } from "../../helper/helper.module";
import { NielExpansionModule, MultiSelectModule, ProgressLoaderModule,TabModule,MessageService,
    FilterListModule,NielDatepickerModule,NielDatepicker,MatCheckboxModule,MatDialogModule,DropdownModule,MatChipsModule,MatCardModule,MatTableModule,
    ConfirmDialogModule,MatPaginatorModule} from '../../lib/lib.module';
import { MatFormFieldModule,MatInputModule} from '@angular/material';
import { FormsModule } from "@angular/forms";
import { Http, RequestOptions, XHRBackend, HttpModule } from "@angular/http";
import { HttpFactory } from "../shared/services/interceptor.service";
import { SharedService } from "../shared/services/shared.service";
import { SurveyPanelService } from "./survey-panel/survey-panel.service";
import { SharedModule } from "../shared/shared.module";
import { BrowserModule } from "@angular/platform-browser";
import { SourcePanelComponent } from './source-panel/source-panel.component';
// import { routing} from './survey.routing'
import { Routes, RouterModule } from '@angular/router';
import { DialogOverviewExampleDialog } from "../shared/component/dialog-overview.component";

const surveyRoutes: Routes = [
	{
		path: '',
		redirectTo: '/survey-panel',
		pathMatch: 'full'
	},{
		path: 'survey-panel',
		component: SurveyPanelComponent,
	},{
		path: 'source-panel',
		component: SourcePanelComponent,
	}
];
@NgModule({
    imports: [
        // Angular Modules
        FormsModule,
        CommonModule,
        HttpModule,
        MatFormFieldModule,
        MatInputModule,
        // BrowserModule,

        // Control Modules
        HelperModule,
        NielExpansionModule,
        MultiSelectModule,
        RouterModule.forChild(surveyRoutes),
        ProgressLoaderModule.forRoot({
            animationType: 'custom-circle',
            fillColor: 'none',
            fullScreenBackdrop: true
        }),
        TabModule,
        FilterListModule,
        // Application module
        SharedModule,
        NielDatepickerModule,
        MatCheckboxModule,
        MatDialogModule,
        DropdownModule,
        MatChipsModule,
        MatCardModule,
        MatTableModule,
        ConfirmDialogModule,
        MatPaginatorModule
    ],
    exports: [SurveyPanelComponent,SourcePanelComponent],
    entryComponents:[DialogOverviewExampleDialog],
    declarations: [SurveyPanelComponent, SourcePanelComponent],
    providers: [SurveyPanelService, {
        provide: Http,
        useFactory: HttpFactory,
        deps: [XHRBackend, RequestOptions, SharedService, MessageService]
    }]
})

export class SurveyModule { }