import { Component, OnInit } from '@angular/core';
import { SurveyPanelService } from './survey-panel.service';
import { error } from 'selenium-webdriver';
import { SharedService } from '../../shared/services/shared.service';
import { MessageService, MessageType } from '../../../lib/lib.module';
import { surveyinfo,surveydimension } from './survey';
import { Router} from '@angular/router'
@Component({
  selector: 'app-survey-panel',
  templateUrl: './survey-panel.component.html',
  styleUrls: ['./survey-panel.component.scss']
})
export class SurveyPanelComponent implements OnInit {

  // mockdata=[{key:'one',value:['value1','value2','value3']},{key:'two',value:['value2']},{key:'three',value:['value3']}]
  // one: {[k: string]: any} = {};
  // two: {[k: string]: any} = {};
  // three: {[k: string]: any} = {};
  // mm = new Mock();
  
  tabs: any;
  survey_dimension: any[];
  highlight: string;
  private clients: any[];
  private countries: any[];
  private selectedClients: any[];
  private selectedClient: any;
  private selectedCountry: any;
  private surveys: any[];
  private survey_data:any;
  constructor(private surveyPanelService: SurveyPanelService, private sharedService: SharedService,private route:Router) {
    this.surveyPanelService.getClientandCountries().subscribe(data => {
      this.clients = JSON.parse(data["clients"]);
      this.countries = JSON.parse(data["countries"]);
      this.selectedClients = this.clients;
      this.getSurveys();
    });
  }

  ngOnInit() {
 this.survey_data=surveyinfo;
 this.survey_dimension=surveydimension;
  }
  onclose(event):void{
    this.survey_dimension=event
  }
  createSurvey(): void {
    this.surveyPanelService.addSurvey(this.selectedClient, this.selectedCountry).subscribe(data => {
      this.selectedClient = this.selectedCountry = '';
      this.getSurveys();
    });
  }
  
  listdata(event){
    console.log(event)
  }
  getSurveys(): void {
    this.surveyPanelService.getSurveyByClient(this.selectedClients).subscribe(data => {
      this.surveys = data;
    });
  }
  _routeSource(){
    this.route.navigate(['source-panel'])
  }
}
export class Mock{
  key:string;
  value:string[];
}

