import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse} from '@angular/common/http';
import { Observable} from 'rxjs';
import { ExtensionService } from '../../../helper/service/extend.service';
import { map,catchError} from 'rxjs/operators';
@Injectable()
export class SurveyPanelService extends ExtensionService {

    private GETCLIENTS: string = "getclients";
    private GETCOUNTRIES: string = "getcountries";
    private GETCLIENTSANDCOUNTRIES: string = "getclientsandcountries";
    private GETSURVEYS: string = "getsurveys";
    private GETSURVEYSBYCLIENT: string = "getsurveysbyclient";
    private ADDSURVEY: string = "addsurvey";
    
    constructor(private http: Http) {
        super();
    }

    public getClients(): Observable<any> {
        return this.http.get(this.GETCLIENTS).pipe(map(response=>response.json()),catchError(error => Observable.throw(error)));
    }

    public getCountries(): Observable<any> {
        return this.http.get(this.GETCOUNTRIES).pipe(map(response=>response.json()),catchError(error => Observable.throw(error)));
    }

    public getClientandCountries(): Observable<any> {
        return this.http.get(this.GETCLIENTSANDCOUNTRIES).pipe(map(response=>response.json()),catchError(error => Observable.throw(error)));
    }

    public getSurveys(): Observable<any> {
        return this.http.get(this.GETSURVEYS).pipe(map(response=>response.json()),catchError(error => Observable.throw(error)));
    }

    public getSurveyByClient(clients?: any[]): Observable<any> {
        let options = clients ? super.getRequestOptions([{ "clients": clients.map(i => i.name).join(",") }]) : null;
        return this.http.get(this.GETSURVEYSBYCLIENT, options).pipe(map(response=>response.json()),catchError(error => Observable.throw(error)));
    }

    public addSurvey(client: string, country: string): Observable<any> {
        let options = super.getRequestOptions([{ "clientname": client }, { "countryname": country }]);
        return this.http.post(this.ADDSURVEY, '', options).pipe(map(response=>response.json()),catchError(error => Observable.throw(error)));
    }
}