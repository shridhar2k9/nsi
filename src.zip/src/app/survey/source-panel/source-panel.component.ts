import { Component, OnInit,Inject } from '@angular/core';
import { surveyinfo,surveydimension,Source } from '../survey-panel/survey';
import {NielDialog,NielDialogRef, MAT_DIALOG_DATA,ConfirmationService, MatPaginator} from '../../../lib/lib.module';
import {MatChipInputEvent} from '@angular/material';
import {ENTER, COMMA} from '@angular/cdk/keycodes';
import {MatTableDataSource} from '@angular/material';
import {sourcedimension}from '../survey-panel/survey';
import { DialogOverviewExampleDialog } from '../../shared/component/dialog-overview.component';
import { ViewChild } from '@angular/core';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  {position: 11, name: 'Sodium', weight: 22.9897, symbol: 'Na'},
  {position: 12, name: 'Magnesium', weight: 24.305, symbol: 'Mg'},
  {position: 13, name: 'Aluminum', weight: 26.9815, symbol: 'Al'},
  {position: 14, name: 'Silicon', weight: 28.0855, symbol: 'Si'},
  {position: 15, name: 'Phosphorus', weight: 30.9738, symbol: 'P'},
  {position: 16, name: 'Sulfur', weight: 32.065, symbol: 'S'},
  {position: 17, name: 'Chlorine', weight: 35.453, symbol: 'Cl'},
  {position: 18, name: 'Argon', weight: 39.948, symbol: 'Ar'},
  {position: 19, name: 'Potassium', weight: 39.0983, symbol: 'K'},
  {position: 20, name: 'Calcium', weight: 40.078, symbol: 'Ca'},
  {position: 21, name: 'Sodium', weight: 22.9897, symbol: 'Na'},
  {position: 22, name: 'Magnesium', weight: 24.305, symbol: 'Mg'},
  {position: 23, name: 'Aluminum', weight: 26.9815, symbol: 'Al'},
  {position: 24, name: 'Silicon', weight: 28.0855, symbol: 'Si'},
  {position: 25, name: 'Phosphorus', weight: 30.9738, symbol: 'P'},
  {position: 26, name: 'Sulfur', weight: 32.065, symbol: 'S'},
  {position: 27, name: 'Chlorine', weight: 35.453, symbol: 'Cl'},
  {position: 28, name: 'Argon', weight: 39.948, symbol: 'Ar'},
  {position: 29, name: 'Potassium', weight: 39.0983, symbol: 'K'},
  {position: 30, name: 'Calcium', weight: 40.078, symbol: 'Ca'},
  {position: 31, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 32, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 33, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 34, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 35, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 36, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 37, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 38, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 39, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 40, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  {position: 41, name: 'Sodium', weight: 22.9897, symbol: 'Na'},
  {position: 42, name: 'Magnesium', weight: 24.305, symbol: 'Mg'},
  {position: 43, name: 'Aluminum', weight: 26.9815, symbol: 'Al'},
  {position: 44, name: 'Silicon', weight: 28.0855, symbol: 'Si'},
  {position: 45, name: 'Phosphorus', weight: 30.9738, symbol: 'P'},
  {position: 46, name: 'Sulfur', weight: 32.065, symbol: 'S'},
  {position: 47, name: 'Chlorine', weight: 35.453, symbol: 'Cl'},
  {position: 48, name: 'Argon', weight: 39.948, symbol: 'Ar'},
  {position: 49, name: 'Potassium', weight: 39.0983, symbol: 'K'},
  {position: 50, name: 'Calcium', weight: 40.078, symbol: 'Ca'},
  {position: 51, name: 'Sodium', weight: 22.9897, symbol: 'Na'},
  {position: 52, name: 'Magnesium', weight: 24.305, symbol: 'Mg'},
  {position: 53, name: 'Aluminum', weight: 26.9815, symbol: 'Al'},
  {position: 54, name: 'Silicon', weight: 28.0855, symbol: 'Si'},
  {position: 55, name: 'Phosphorus', weight: 30.9738, symbol: 'P'},
  {position: 56, name: 'Sulfur', weight: 32.065, symbol: 'S'},
  {position: 57, name: 'Chlorine', weight: 35.453, symbol: 'Cl'},
  {position: 58, name: 'Argon', weight: 39.948, symbol: 'Ar'},
  {position: 59, name: 'Potassium', weight: 39.0983, symbol: 'K'},
  {position: 60, name: 'Calcium', weight: 40.078, symbol: 'Ca'},
];


@Component({
  selector: 'app-source-panel',
  templateUrl: './source-panel.component.html',
  styleUrls: ['./source-panel.component.css'],
  providers:[ConfirmationService]
})
export class SourcePanelComponent implements OnInit {
  displayedColumnss: string[];
  source_dimention: { title: string; }[];
  survey_dimension: { title: string; }[];
  survey_data: { id: number; name: string; }[];
  YourDialog:string;
  truevar:boolean;
  animal: string;
  name: string;

  visible: boolean = true;
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = true;

  // Enter, comma
  separatorKeysCodes = [ENTER, COMMA];
  fruits = [
    { name: 'PeriodId' },
    { name: 'FrequencyId' },
    { name: 'YearNUM' },
    { name: 'SequenNUM' },
    { name: 'SequenId' },
    { name: 'InIDTE' },
  ];
  selectedCity: string;
  cars: { label: string; value: string; }[];
  displayedColumns:any;
  // dataSource = ELEMENT_DATA;
  msgs:any = [];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(public dialog: NielDialog,public confirmationService:ConfirmationService) {}

  ngOnInit() {
    this.survey_data=surveyinfo;
 this.survey_dimension=surveydimension;    
 this.source_dimention=sourcedimension;
 this.cars = [
  {label: 'Audi', value: 'Audi'},
  {label: 'BMW', value: 'BMW'},
  {label: 'Fiat', value: 'Fiat'},
  {label: 'Ford', value: 'Ford'},
  {label: 'Honda', value: 'Honda'},
  {label: 'Jaguar', value: 'Jaguar'},
  {label: 'Mercedes', value: 'Mercedes'},
  {label: 'Renault', value: 'Renault'},
  {label: 'VW', value: 'VW'},
  {label: 'Volvo', value: 'Volvo'}
];
this.selectedCity='Audi';
this.displayedColumns= ['position','name','weight','symbol'];
this.displayedColumnss= ['position','name','weight','symbol','action'];
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator
  }

  confirm(event) {
    this.confirmationService.confirm({
          message: 'Do you want to Delete this record?',
          header: 'Delete Confirmation',
          accept: () => {
             alert(event)
          },
          reject: () => {
              alert(event)
          }
      });
  }

  remove(fruit: any): void {
    let index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }


  openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '400px',
      data: { name: 'asdadasda', animal: "csdfsdsdsds" }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
}
onclose(event):void{
  this.survey_dimension=event
}
applyFilter(filterValue: string) {
  this.dataSource.filter = filterValue.trim().toLowerCase();
  this.paginator.updatePageLinks();
}
}


